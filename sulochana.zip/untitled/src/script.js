// Contact form submission (just a demo)

document.getElementById("contactForm").addEventListener("submit", function(event) {

  event.preventDefault();

  document.getElementById("successMsg").innerText = "✅ Message sent successfully!";

  

  // Clear form fields

  this.reset();

});